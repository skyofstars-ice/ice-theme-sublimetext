### Material Brogrammer
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Brogrammer.png)

### Material Cobalt
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Cobalt.png)

### Material Flatland
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Flatland.png)

### Material Monokai
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Monokai.png)

### Material Oceanic Next
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Oceanic%20Next.png)

### Material Seti
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Seti.png)

### Material Solarized Dark
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Solarized%20Dark.png)

### Material Solarized Light
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Solarized%20Light.png)

### Material Spacegray
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Spacegray.png)

### Material Stereokai
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Stereokai.png)

### Material Twilight
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Twilight.png)

### Material Zenburn
![](https://raw.githubusercontent.com/saadq/Materialize/master/screenshots/Material%20Zenburn.png)


*The font used in the screenshot is [__Fira Mono__](https://mozilla.github.io/Fira/).*

---

[Go back to the README](/README.md)